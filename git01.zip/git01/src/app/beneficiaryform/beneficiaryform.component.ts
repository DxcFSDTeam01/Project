import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-beneficiaryform',
  templateUrl: './beneficiaryform.component.html',
  styleUrls: ['./beneficiaryform.component.css']
})
export class BeneficiaryformComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
