import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { AccountsComponent } from './accounts/accounts.component';
import { EnquiryComponent } from './enquiry/enquiry.component';
import { CheckbalanceComponent } from './checkbalance/checkbalance.component';
import { RequestministatementComponent } from './requestministatement/requestministatement.component';
import { RequestmonannperstatementComponent } from './requestmonannperstatement/requestmonannperstatement.component';
import { TransferfundsComponent } from './transferfunds/transferfunds.component';
import { PayutilitybillsComponent } from './payutilitybills/payutilitybills.component';
import { TranactionsComponent } from './tranactions/tranactions.component';


const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: '/home' },
  { path: 'home', component: HomeComponent },
  { path: 'reg', component: RegisterComponent },
  { path: 'addAcc', component: AccountsComponent },
  { path: 'enquiry', component: EnquiryComponent },
  { path: 'checkbal', component: CheckbalanceComponent },
  { path: 'reqministat', component: RequestministatementComponent },
  { path: 'reqmon', component: RequestmonannperstatementComponent },
  { path: 'transfun', component: TransferfundsComponent },
  { path: 'pay', component: PayutilitybillsComponent },
  { path: 'trans', component: TranactionsComponent },
  


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }


