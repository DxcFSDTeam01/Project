import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tranactions',
  templateUrl: './tranactions.component.html',
  styleUrls: ['./tranactions.component.css']
})
export class TranactionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
