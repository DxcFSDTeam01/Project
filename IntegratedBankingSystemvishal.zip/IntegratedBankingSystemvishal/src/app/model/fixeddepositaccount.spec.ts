import { Fixeddepositaccount } from './fixeddepositaccount';

describe('Fixeddepositaccount', () => {
  it('should create an instance', () => {
    expect(new Fixeddepositaccount()).toBeTruthy();
  });
});
