export class Fixeddepositaccount {
    public fdPeriod: number;
    public amountLimit: number;

}
