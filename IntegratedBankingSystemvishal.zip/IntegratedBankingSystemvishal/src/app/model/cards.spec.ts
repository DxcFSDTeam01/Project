import { Cards } from './cards';

describe('Cards', () => {
  it('should create an instance', () => {
    expect(new Cards()).toBeTruthy();
  });
});
