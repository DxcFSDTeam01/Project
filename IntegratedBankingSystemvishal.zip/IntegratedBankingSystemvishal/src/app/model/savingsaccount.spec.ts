import { Savingsaccount } from './savingsaccount';

describe('Savingsaccount', () => {
  it('should create an instance', () => {
    expect(new Savingsaccount()).toBeTruthy();
  });
});
