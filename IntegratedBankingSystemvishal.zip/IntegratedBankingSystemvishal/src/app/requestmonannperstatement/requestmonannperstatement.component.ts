import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requestmonannperstatement',
  templateUrl: './requestmonannperstatement.component.html',
  styleUrls: ['./requestmonannperstatement.component.css']
})
export class RequestmonannperstatementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
