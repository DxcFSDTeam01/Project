import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { AccountsComponent } from './accounts/accounts.component';
import { FooterComponent } from './footer/footer.component';
import { SuccessComponent } from './success/success.component';
import { EnquiryComponent } from './enquiry/enquiry.component';
import { CheckbalanceComponent } from './checkbalance/checkbalance.component';
import { RequestministatementComponent } from './requestministatement/requestministatement.component';
import { RequestmonannperstatementComponent } from './requestmonannperstatement/requestmonannperstatement.component';
import { TransferfundsComponent } from './transferfunds/transferfunds.component';
import { PayutilitybillsComponent } from './payutilitybills/payutilitybills.component';
import { TranactionsComponent } from './tranactions/tranactions.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    RegisterComponent,
    AccountsComponent,
    FooterComponent,
    SuccessComponent,
    EnquiryComponent,
    CheckbalanceComponent,
    RequestministatementComponent,
    RequestmonannperstatementComponent,
    TransferfundsComponent,
    PayutilitybillsComponent,
    TranactionsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FontAwesomeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
