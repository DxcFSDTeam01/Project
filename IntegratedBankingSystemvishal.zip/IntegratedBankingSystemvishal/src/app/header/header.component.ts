import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { faHome, faAddressCard, faCreditCard,faQuestion,faEnvelope} from '@fortawesome/free-solid-svg-icons';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {


  brand: string;
  links: any[];

  constructor(private router: Router) {


    this.brand = environment.logo;
    this.links = [
      { icon: faHome, path: '/home', linkText: 'Home' },
      
      { icon: faCreditCard, path: '/addAcc', linkText: 'Accounts' },
      { icon: faQuestion, path: '/enquiry', linkText: 'Enquiry' },
      { icon: faEnvelope, path: '/trans', linkText: 'Transaction' },
      
    ];

  }

  ngOnInit(): void {
  }

}
