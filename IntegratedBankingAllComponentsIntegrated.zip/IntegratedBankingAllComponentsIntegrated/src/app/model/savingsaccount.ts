export class Savingsaccount {
    public withDrawLimit: number;
    public utilityLimit: number;
    public utilityDate: Date;
}
