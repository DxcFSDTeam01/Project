export class Cards {
    public name: string;
    public cardnumber: number;
    public cvv: number;
    public validfrom: Date;
    public validthrough: Date;
    public pin: number;
}
