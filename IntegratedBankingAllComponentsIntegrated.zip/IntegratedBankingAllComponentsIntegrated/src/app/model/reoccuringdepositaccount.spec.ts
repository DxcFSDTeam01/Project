import { Reoccuringdepositaccount } from './reoccuringdepositaccount';

describe('Reoccuringdepositaccount', () => {
  it('should create an instance', () => {
    expect(new Reoccuringdepositaccount()).toBeTruthy();
  });
});
