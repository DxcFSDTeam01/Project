import { Bankrepresentative } from './bankrepresentative';

describe('Bankrepresentative', () => {
  it('should create an instance', () => {
    expect(new Bankrepresentative()).toBeTruthy();
  });
});
