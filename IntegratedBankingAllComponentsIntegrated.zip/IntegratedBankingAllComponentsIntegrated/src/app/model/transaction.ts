export class Transaction {
    public transId: number;
    public accountType: string;
    public cardNumber: number;
    public transactionType: string;
    public amount: number;

}
