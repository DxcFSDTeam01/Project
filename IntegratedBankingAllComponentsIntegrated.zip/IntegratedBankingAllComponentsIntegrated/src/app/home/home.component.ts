import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { faHome, faAddressCard, faCreditCard, faQuestion, faEnvelope, faCog } from '@fortawesome/free-solid-svg-icons';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  brand: string;
  links: any[];
  constructor(private router: Router) {


    this.brand = environment.logo;
    this.links = [
      { icon: faHome, path: '/home', linkText: 'Home' },
      { icon: faCog, path: '/enquiry', linkText: 'Services' },
      { icon: faCreditCard, path: '/addAcc', linkText: 'Accounts' },
      { icon: faEnvelope, path: '/trans', linkText: 'Transaction' },

    ];

  }
  ngOnInit(): void {

  }
  logout() {

    this.router.navigateByUrl("/login");
  }

}
