import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-tranactions',
  templateUrl: './tranactions.component.html',
  styleUrls: ['./tranactions.component.css']
})
export class TranactionsComponent implements OnInit {

  itemForm: FormGroup;
  isEditing: boolean = false;
  accountTypes: string[];
  transactionTypes: string[];

  constructor(private activatedRoute: ActivatedRoute,

    private router: Router,
    private formBuilder: FormBuilder) {
    this.itemForm = formBuilder.group({
      transactionId: ['', Validators.required],
      accountType: ['', Validators.required],
      cardNumber: ['', Validators.required],
      transactionType: ['', Validators.required],
      transactionDate: ['', Validators.required],
      amount: ['', Validators.required]
    });

    this.accountTypes = ["Savings Account", "Reoccuring deposit Account", "Fixed Deposit"];
    this.transactionTypes = ["Withdraw", "Deposit", "Transfer"];
  }
  get f() {
    return this.itemForm.controls;
  }

  ngOnInit(): void {
  }

}
