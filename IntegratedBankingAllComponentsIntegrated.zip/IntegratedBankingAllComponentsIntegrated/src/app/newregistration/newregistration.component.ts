import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-newregistration',
  templateUrl: './newregistration.component.html',
  styleUrls: ['./newregistration.component.css']
})
export class NewregistrationComponent implements OnInit {
  itemForm: FormGroup;
  isEditing: boolean = false;
  constructor(private activatedRoute: ActivatedRoute,
  
    private router: Router,
    private formBuilder : FormBuilder) { 
      this.itemForm = formBuilder.group({
        firstName: ['',Validators.required],
        lastName: ['',Validators.required],
        email: ['',Validators.required],
        password: ['',Validators.required],
        confirmPassword: ['',Validators.required],
        birthDate: ['',Validators.required],
      
        phoneNumber: ['',Validators.required],
        address: ['',Validators.required],
        PanCard: ['',Validators.required],
        adhaarCard: ['',Validators.required]      
      });
  
    }
    get f(){
      return this.itemForm.controls;
    }
    

  ngOnInit(): void {
  }

}