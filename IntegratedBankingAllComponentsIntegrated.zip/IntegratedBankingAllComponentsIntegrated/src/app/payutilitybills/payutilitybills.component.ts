import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payutilitybills',
  templateUrl: './payutilitybills.component.html',
  styleUrls: ['./payutilitybills.component.css']
})
export class PayutilitybillsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
