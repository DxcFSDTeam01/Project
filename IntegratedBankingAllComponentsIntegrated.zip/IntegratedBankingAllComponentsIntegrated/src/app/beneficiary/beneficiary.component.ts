
import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-beneficiary',
  templateUrl: './beneficiary.component.html',
  styleUrls: ['./beneficiary.component.css']
})
export class BeneficiaryComponent implements OnInit {
  itemForm: FormGroup;
  isEditing: boolean = false;
  transactionTypes: string[];

  constructor(private activatedRoute: ActivatedRoute,

    private router: Router,
    private formBuilder: FormBuilder) {
    this.itemForm = formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      accountNumber: ['', Validators.required],
      ifsc: ['', Validators.required],
      phoneNumber: ['', Validators.required],
      transactionType: ['', Validators.required],

      amount: ['', Validators.required]
    });
    this.transactionTypes = ["Withdraw", "Deposit", "Transfer"];
  }
  get f() {
    return this.itemForm.controls;
  }



  ngOnInit(): void {
    throw new Error("Method not implemented.");
  }

}
