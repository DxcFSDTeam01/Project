import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckbalanceComponent } from './checkbalance.component';

describe('CheckbalanceComponent', () => {
  let component: CheckbalanceComponent;
  let fixture: ComponentFixture<CheckbalanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckbalanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckbalanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
